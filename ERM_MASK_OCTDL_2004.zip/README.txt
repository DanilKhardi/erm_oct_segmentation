ERM_OCTDL_LOCTSEG - маски ERM, полученные с помощью обученной модели LOCTSeg

ERM_OCTDL_LOCTSEG+UNET - маски ERM, полученные путем объединения предсказаний моделей LOCTSeg+UNet
Обучение UNet проводилось на основе данных ERM_OCTDL_LOCTSEG. Тестовая выборка состояла из 20/155 ERM


ERM_OCTDL_LOCTSEG+UNET_v2 - маски ERM, полученные путем объединения предсказаний моделей LOCTSeg+UNet
Обучение UNet проводилось на основе данных ERM_OCTDL_LOCTSEG. Тестовая выборка состояла из 20/155 ERM

ERM_OCTDL_LOCTSEG+UNET_v3 - маски ERM, полученные путем объединения предсказаний моделей LOCTSeg+UNet
В эту версию вошли лучший результ из ERM_OCTDL_LOCTSEG+UNET и ERM_OCTDL_LOCTSEG+UNET_v2. 
Дополнительно маски прошли ручную корректировку.